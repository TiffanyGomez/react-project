"use client";

import React, { useState } from "react";
import { ArrowSmallDownIcon } from "@heroicons/react/24/solid";
import "../styles/NavBar.css"; // Import custom CSS if needed


export function Posts() {
  const [activeTab, setActiveTab] = useState("trends");

  const tabs = [
    { id: "trends", label: "Men" },
    { id: "frontend", label: "Women" },
    { id: "backend", label: "Child" },
    { id: "cloud", label: "Sold" },
    { id: "ai", label: "Accessory" },
    { id: "tools", label: "Tools" },
  ];

  return (
    <section className="grid min-h-screen place-items-center p-8 bg-gray-100">
      {/* Tabs Section */}
      <div className="relative mx-auto max-w-4xl w-full">
        <div className="relative flex justify-between bg-gray-300 rounded-full p-1">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`relative z-10 flex-1 text-center py-2 rounded-full transition-all duration-300 ${
                activeTab === tab.id ? "text-white" : "text-gray-600"
              }`}
            >
              {tab.label}
            </button>
          ))}

          {/* Sliding White Indicator */}
          <div
            className="absolute top-0 left-0 h-full bg-white rounded-full shadow-md transition-all duration-300 ease-in-out"
            style={{
              width: `${100 / tabs.length}%`,
              transform: `translateX(${tabs.findIndex((tab) => tab.id === activeTab) * 100}%)`,
            }}
          />
        </div>
      </div>

      {/* Tab Content Section */}
      <div className="container mx-auto flex justify-center items-center flex-col mt-16">
        <div className="mb-4">
          <h1 className="text-4xl font-bold text-center">Tab Content for {activeTab}</h1>
          <p className="text-center mt-2 text-gray-600">
            You are currently viewing the {activeTab} content.
          </p>
        </div>
        <button className="flex items-center gap-2 mt-6 py-2 px-4 bg-gray-800 text-white rounded-full">
          <ArrowSmallDownIcon className="h-5 w-5 font-bold text-white" />
          View More
        </button>
      </div>
    </section>
  );
}

export default Posts;

