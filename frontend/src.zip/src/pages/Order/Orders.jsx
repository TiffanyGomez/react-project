import React from 'react'

const Orders = () => {
  return (
    <div>

      Order
      
    </div>
  )
}

export default Orders
