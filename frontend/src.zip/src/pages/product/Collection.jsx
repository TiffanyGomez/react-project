import React from 'react'

const Collection = () => {
  return (
    <div>
      
      collection

    </div>
  )
}

export default Collection
